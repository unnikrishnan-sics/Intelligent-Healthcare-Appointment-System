const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');

dotenv.config();

const app = express();

// Middleware
const corsOptions = {
    origin: ['https://ihasfrontend.vercel.app', 'http://localhost:5173', 'http://localhost:5000', 'http://127.0.0.1:5173'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));
app.options(/.*/, cors(corsOptions)); // Enable pre-flight for all routes
app.use(express.json());

// DB Connection Middleware
app.use(async (req, res, next) => {
    await connectDB();
    await seedAdmin(); // Run seed check (safe due to internal caching)
    next();
});

// Routes
app.get('/', (req, res) => {
    res.send('API is running...');
});

// Define Routes
app.use('/api/auth', require('./routes/authRoutes'));

const PORT = process.env.PORT || 5000;

const seedAdmin = require('./scripts/seedAdmin');

app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
    seedAdmin(); // Auto-seed on local startup
});

// Global 404 Error Handler
app.use((req, res, next) => {
    res.status(404).json({ message: 'Route not found' });
});

module.exports = app;