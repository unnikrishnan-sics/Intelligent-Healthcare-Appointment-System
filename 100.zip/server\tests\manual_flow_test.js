const axios = require('axios');
const mongoose = require('mongoose');

const BASE_URL = 'http://localhost:5000/api';
let adminToken, doctorToken, patientToken;
let doctorId, patientId, appointmentId;

const log = (msg) => console.log(`[TEST] ${msg}`);
const errLog = (msg, err) => {
    console.error(`[ERROR] ${msg}`);
    if (err.response) {
        console.error('Response Data:', err.response.data);
        console.error('Response Status:', err.response.status);
    } else if (err.request) {
        console.error('No Response Received:', err.request);
    } else {
        console.error('Error Message:', err.message);
    }
};

async function runTest() {
    try {
        log('Starting System Verification...');

        // 1. Admin Login
        log('1. Logging in as Admin...');
        const adminRes = await axios.post(`${BASE_URL}/auth/login`, {
            email: 'admin@gmail.com',
            password: 'admin@123'
        });
        adminToken = adminRes.data.token;
        log('   Admin Logged In.');

        // 2. Register Doctor
        log('2. Registering new Doctor...');
        const docEmail = `doc_test_${Date.now()}@example.com`;
        const docRes = await axios.post(`${BASE_URL}/auth/register`, {
            name: 'Test Doctor',
            email: docEmail,
            password: 'password123',
            role: 'doctor'
        });
        // Should NOT return token, but message
        if (docRes.data.token) throw new Error('Doctor got token immediately!');
        log('   Doctor Registered (Pending Approval).');

        // Need to find the doctor's ID. Since we don't have token, we use Admin to find the user.
        const usersRes = await axios.get(`${BASE_URL}/admin/users`, {
            headers: { Authorization: `Bearer ${adminToken}` }
        });
        const doctorUser = usersRes.data.find(u => u.email === docEmail);
        doctorId = doctorUser._id;
        log(`   Doctor ID found: ${doctorId}`);

        // 3. Approve Doctor
        log('3. Approving Doctor...');
        await axios.put(`${BASE_URL}/admin/users/${doctorId}/status`, { status: 'active' }, {
            headers: { Authorization: `Bearer ${adminToken}` }
        });
        log('   Doctor Approved.');

        // 4. Doctor Login
        log('4. Logging in as Doctor...');
        const docLoginRes = await axios.post(`${BASE_URL}/auth/login`, {
            email: docEmail,
            password: 'password123'
        });
        doctorToken = docLoginRes.data.token;
        log('   Doctor Logged In.');

        // 5. Create Doctor Profile & Schedule
        // Check if doctor profile exists, if not create (This part might be missing in auth flow, usually done on first login or separate step. 
        // Based on previous code, we need to create a profile to have availability.)
        // Let's assume there's an endpoint to update profile/availability.
        // Checking routes... likely POST /api/doctors/profile or PUT /api/doctors/profile
        log('5. Setting Doctor Availability...');
        // First ensure doctor profile object exists. check doctorController.
        // Assuming updateProfile handles upsert.
        const availability = [
            { day: 'Monday', startTime: '09:00', endTime: '17:00' },
            { day: 'Tuesday', startTime: '09:00', endTime: '17:00' },
            { day: 'Wednesday', startTime: '09:00', endTime: '17:00' },
            { day: 'Thursday', startTime: '09:00', endTime: '17:00' },
            { day: 'Friday', startTime: '09:00', endTime: '17:00' }
        ];

        // Try creating/updating profile.
        // Note: We need to know the endpoint. Guessing based on Doctor Controller tasks.
        try {
            await axios.post(`${BASE_URL}/doctors/profile`, {
                specialization: 'General',
                experience: 5,
                feesPerConsultation: 50,
                bio: 'Expert Doctor',
                availability
            }, {
                headers: { Authorization: `Bearer ${doctorToken}` }
            });
            log('   Doctor Profile/Availability Set.');
        } catch (e) {
            log('   (Note) Failed to set profile, maybe endpoint differs. Skipping availability check logic strictly.');
        }

        // 6. Register Patient
        log('6. Registering Patient...');
        const patEmail = `pat_test_${Date.now()}@example.com`;
        const patRes = await axios.post(`${BASE_URL}/auth/register`, {
            name: 'Test Patient',
            email: patEmail,
            password: 'password123',
            role: 'patient'
        });
        patientToken = patRes.data.token;
        // Patient gets token immediately
        if (!patientToken) throw new Error('Patient did not get token!');
        patientId = patRes.data._id;
        log('   Patient Registered & Logged In.');

        // 7. Book Appointment
        log('7. Booking Appointment...');
        // Need a future Monday date
        const nextMonday = new Date();
        nextMonday.setDate(nextMonday.getDate() + ((1 + 7 - nextMonday.getDay()) % 7));
        if (nextMonday < new Date()) nextMonday.setDate(nextMonday.getDate() + 7);
        const dateStr = nextMonday.toISOString().split('T')[0];

        // Need the user ID of the doctor for booking. The appointment controller uses `doctorId` from body.
        // Tests showed we pass the User ID of the doctor.
        try {
            const bookRes = await axios.post(`${BASE_URL}/appointments`, {
                doctorId: doctorId,
                date: dateStr,
                timeSlot: '10:00',
                reason: 'Routine Checkup'
            }, {
                headers: { Authorization: `Bearer ${patientToken}` }
            });
            appointmentId = bookRes.data._id;
            log(`   Appointment Booked: ${appointmentId}`);
        } catch (e) {
            // If availability check fails (because profile wasn't set correctly above), this might fail.
            errLog('Booking Failed', e);
            return;
        }

        // 8. Doctor Confirms Appointment
        log('8. Doctor Confirming Appointment...');
        await axios.put(`${BASE_URL}/appointments/${appointmentId}/status`, {
            status: 'Confirmed'
        }, {
            headers: { Authorization: `Bearer ${doctorToken}` }
        });
        log('   Appointment Confirmed.');

        // 9. Patient Verify Status
        log('9. Patient Checking Status...');
        const myApts = await axios.get(`${BASE_URL}/appointments/my`, {
            headers: { Authorization: `Bearer ${patientToken}` }
        });
        const myApt = myApts.data.find(a => a._id === appointmentId);
        if (myApt.status !== 'Confirmed') throw new Error(`Status mismatch. Expected Confirmed, got ${myApt.status}`);
        log('   Patient sees Confirmed status.');

        log('SUCCESS: Full Flow Verified!');

    } catch (error) {
        errLog('Test Failed', error);
    }
}

runTest();
