
const mongoose = require('mongoose');
const Doctor = require('./server/models/Doctor');
const Appointment = require('./server/models/Appointment');
const User = require('./server/models/User'); // Added User model

const runTest = async () => {
    try {
        console.log("Connecting...");
        await mongoose.connect('mongodb://127.0.0.1:27017/ihas_db');
        console.log('MongoDB Connected');

        // 1. Get a Doctor
        console.log("Fetching doctor...");
        const doctor = await Doctor.findOne().populate('userId', 'name');
        if (!doctor) {
            console.log("No doctor found to test with.");
            return;
        }
        console.log(`Testing with Doctor: ${doctor._id} (User: ${doctor.userId})`);

        // 2. Mock Request Data
        // Valid Day lookup
        const today = new Date();
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        // Find a day the doctor IS available
        const availableDay = doctor.availability[0];
        if (!availableDay) {
            console.log("Doctor has no availability set.");
            return;
        }

        console.log(`Doctor is available on: ${availableDay.day} (${availableDay.startTime}-${availableDay.endTime})`);

        // Calculate a valid date for this day
        let testDate = new Date();
        while (days[testDate.getDay()] !== availableDay.day) {
            testDate.setDate(testDate.getDate() + 1);
        }
        const dateStr = testDate.toISOString().split('T')[0];
        const timeSlot = availableDay.startTime; // Use start time as slot

        console.log(`Testing Date: ${dateStr}`);
        console.log(`Testing TimeSlot: ${timeSlot}`);

        // --- REPLICATE CONTROLLER LOGIC ---
        console.log("\n--- START LOGIC CHECK ---");

        // 1. Availability Check
        const inputDate = new Date(dateStr);
        const dayName = days[inputDate.getUTCDay()]; // Using UTCDay as per fix
        console.log(`Derived Day from ${dateStr} (UTC): ${dayName}`);

        const daySchedule = doctor.availability.find(d => d.day === dayName);
        if (!daySchedule) {
            console.log(`FAIL: Doctor not available. Expected ${dayName}, Found: ${doctor.availability.map(d => d.day).join(', ')}`);
        } else {
            console.log(`PASS: Doctor available on ${dayName}`);

            // 2. Time Logic
            const [slotH, slotM] = timeSlot.split(':').map(Number);
            const slotMinutes = slotH * 60 + slotM;

            const [startH, startM] = daySchedule.startTime.split(':').map(Number);
            const startMinutes = startH * 60 + startM;

            const [endH, endM] = daySchedule.endTime.split(':').map(Number);
            const endMinutes = endH * 60 + endM;

            console.log(`SlotMins: ${slotMinutes}, StartMins: ${startMinutes}, EndMins: ${endMinutes}`);

            if (slotMinutes < startMinutes || slotMinutes >= endMinutes) {
                console.log("FAIL: Slot outside hours.");
            } else {
                console.log("PASS: Slot inside hours.");
            }
        }

        // 3. Existing Booking Check
        const existing = await Appointment.findOne({
            doctorId: doctor.userId,
            date: dateStr,
            timeSlot: timeSlot,
            status: { $nin: ['Cancelled', 'Rejected'] }
        });

        if (existing) {
            console.log("FAIL: Slot already booked.");
        } else {
            console.log("PASS: Slot is free.");
        }

        console.log("--- END LOGIC CHECK ---");

    } catch (err) {
        console.error(err);
    } finally {
        await mongoose.disconnect();
        process.exit();
    }
};

runTest();
