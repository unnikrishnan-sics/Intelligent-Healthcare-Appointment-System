
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Doctor = require('./server/models/Doctor');
const User = require('./server/models/User');

dotenv.config({ path: './server/.env' });

const printDoctors = async () => {
    try {
        console.log('Connecting to MongoDB...');
        await mongoose.connect('mongodb://127.0.0.1:27017/ihas_db');
        console.log('MongoDB Connected');

        const doctors = await Doctor.find({}).populate('userId', 'name');

        console.log(`Found ${doctors.length} doctors.`);

        doctors.forEach((doc, index) => {
            console.log(`\n[${index + 1}] Doctor: ${doc.userId?.name || 'Unknown'} (ID: ${doc.userId?._id})`);
            console.log(`    Specs: ${doc.specialization} | Fees: ${doc.feesPerConsultation}`);
            console.log('    Availability:');
            if (doc.availability && doc.availability.length > 0) {
                doc.availability.forEach(avail => {
                    console.log(`      - ${avail.day}: ${avail.startTime} - ${avail.endTime}`);
                });
            } else {
                console.log('      - No availability set.');
            }
        });

    } catch (err) {
        console.error('Debug Script Error:', err);
    } finally {
        await mongoose.disconnect();
        process.exit(0);
    }
};

printDoctors();
