const mongoose = require('mongoose');
const Doctor = require('../models/Doctor');
const User = require('../models/User');

// @desc    Get all doctors
// @route   GET /api/doctors
// @access  Public
const getDoctors = async (req, res) => {
    try {
        const today = new Date().toISOString().split('T')[0];
        const dayName = new Date().toLocaleDateString('en-US', { weekday: 'long' });

        const doctors = await User.aggregate([
            {
                $match: {
                    role: 'doctor',
                    status: 'active'
                }
            },
            {
                $lookup: {
                    from: 'doctors',
                    localField: '_id',
                    foreignField: 'userId',
                    as: 'profile'
                }
            },
            { $unwind: { path: '$profile', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'appointments',
                    let: { doctorId: '$_id' },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ['$doctorId', '$$doctorId'] },
                                        { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$date" } }, today] },
                                        { $in: ['$status', ['Confirmed', 'Pending', 'Completed']] }
                                    ]
                                }
                            }
                        }
                    ],
                    as: 'todayAppointments'
                }
            },
            {
                $lookup: {
                    from: 'appointments',
                    let: {
                        doctorId: '$_id',
                        lastToken: { $ifNull: ['$profile.queueState.lastTokenCalled', 0] }
                    },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ['$doctorId', '$$doctorId'] },
                                        { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$date" } }, today] },
                                        { $eq: ['$tokenNumber', '$$lastToken'] }
                                    ]
                                }
                            }
                        }
                    ],
                    as: 'currentAppointment'
                }
            },
            {
                $lookup: {
                    from: 'appointments',
                    let: { doctorId: '$_id' },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ['$doctorId', '$$doctorId'] },
                                        { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$date" } }, today] },
                                        { $in: ['$status', ['Confirmed', 'Pending']] },
                                        { $eq: ['$queueStatus', 'Waiting'] }
                                    ]
                                }
                            }
                        },
                        { $sort: { priority: 1, tokenNumber: 1 } },
                        { $limit: 1 }
                    ],
                    as: 'nextQueueItem'
                }
            },
            {
                $addFields: {
                    userId: {
                        _id: '$_id',
                        name: '$name',
                        email: '$email',
                        role: '$role',
                        status: '$status'
                    },
                    specialization: { $ifNull: ['$profile.specialization', 'General Specialist'] },
                    bio: { $ifNull: ['$profile.bio', 'Professional healthcare provider.'] },
                    experience: { $ifNull: ['$profile.experience', 0] },
                    feesPerConsultation: { $ifNull: ['$profile.feesPerConsultation', 0] },
                    availability: { $ifNull: ['$profile.availability', []] },
                    queueState: { $ifNull: ['$profile.queueState', { isPaused: false, lastTokenCalled: 0 }] },
                    totalBookings: { $size: '$todayAppointments' },
                    isAvailableToday: {
                        $in: [dayName, { $ifNull: ['$profile.availability.day', []] }]
                    },
                    currentTokenStatus: {
                        $cond: {
                            if: { $gt: [{ $size: '$currentAppointment' }, 0] },
                            then: { $arrayElemAt: ['$currentAppointment.status', 0] },
                            else: 'Idle'
                        }
                    },
                    nextTokenNumber: {
                        $cond: {
                            if: { $gt: [{ $size: '$nextQueueItem' }, 0] },
                            then: { $arrayElemAt: ['$nextQueueItem.tokenNumber', 0] },
                            else: null
                        }
                    }
                }
            },
            {
                $project: {
                    profile: 0,
                    todayAppointments: 0,
                    currentAppointment: 0,
                    nextQueueItem: 0,
                    password: 0,
                    __v: 0
                }
            }
        ]);

        res.json(doctors);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get doctor by ID
// @route   GET /api/doctors/:id
// @access  Public
const getDoctorById = async (req, res) => {
    try {
        const { id } = req.params;

        // Try finding by Doctor document _id first
        let doctor = await Doctor.findById(id).populate('userId', 'name email');

        // If not found, try finding by userId (since frontend often uses userId as doctor ID)
        if (!doctor) {
            doctor = await Doctor.findOne({ userId: id }).populate('userId', 'name email');
        }

        if (doctor) {
            res.json(doctor);
        } else {
            res.status(404).json({ message: 'Doctor not found' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Create/Update Doctor Profile
// @route   POST /api/doctors/profile
// @access  Private (Doctor only)
const updateDoctorProfile = async (req, res) => {
    const { specialization, bio, experience, feesPerConsultation, availability } = req.body;

    // Build profile object
    // Build profile object
    const profileFields = { userId: req.user._id };
    if (specialization) profileFields.specialization = specialization;
    if (bio) profileFields.bio = bio;
    if (experience) profileFields.experience = experience;
    if (feesPerConsultation) profileFields.feesPerConsultation = feesPerConsultation;
    if (availability) profileFields.availability = availability;

    try {
        let doctor = await Doctor.findOne({ userId: req.user._id });

        if (doctor) {
            // Update
            doctor = await Doctor.findOneAndUpdate(
                { userId: req.user._id },
                { $set: profileFields },
                { new: true, runValidators: true }
            );
            return res.json(doctor);
        }

        // Create - Ensure required fields are present if creating new
        // If they are missing, mongoose save() will throw a ValidationError
        doctor = new Doctor(profileFields);
        await doctor.save();
        res.json(doctor);

    } catch (error) {
        console.error('Error in updateDoctorProfile:', error);
        if (error.name === 'ValidationError') {
            return res.status(400).json({ message: error.message });
        }
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get current doctor profile
// @route   GET /api/doctors/profile
// @access  Private (Doctor only)
const getDoctorProfile = async (req, res) => {
    try {
        console.log('getDoctorProfile - User from req:', req.user ? req.user._id : 'undefined');
        // Ensure user is authenticated (redundant if middleware works, but safe)
        if (!req.user) {
            console.log('getDoctorProfile - No user on request');
            return res.status(401).json({ message: 'User not authenticated' });
        }

        const doctor = await Doctor.findOne({ userId: req.user._id });
        if (doctor) {
            console.log('getDoctorProfile - Doctor found:', doctor._id);
            res.json(doctor);
        } else {
            console.log('getDoctorProfile - No doctor profile found for user:', req.user._id);
            // Return empty profile or null instead of 404 to avoid console errors
            res.json(null);
        }
    } catch (error) {
        console.error('Error in getDoctorProfile:', error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get unique patients for the current doctor
// @route   GET /api/doctors/patients
// @access  Private (Doctor only)
const getDoctorPatients = async (req, res) => {
    try {
        // Find all appointments for this doctor
        // We use aggregation to group by patientId to get unique patients
        const patients = await require('../models/Appointment').aggregate([
            { $match: { doctorId: new mongoose.Types.ObjectId(req.user.id) } },
            { $group: { _id: "$patientId", lastAppointmentDate: { $max: "$date" } } },
            { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'patientDetails' } },
            { $unwind: "$patientDetails" },
            {
                $project: {
                    _id: "$patientDetails._id",
                    name: "$patientDetails.name",
                    email: "$patientDetails.email",
                    age: "$patientDetails.age",
                    gender: "$patientDetails.gender",
                    phone: "$patientDetails.phone",
                    lastVisit: "$lastAppointmentDate"
                }
            },
            { $sort: { lastVisit: -1 } }
        ]);

        res.json(patients);
    } catch (error) {
        console.error('Error fetching patients:', error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// @desc    Get detailed history of a patient
// @route   GET /api/doctors/patients/:patientId/history
// @access  Private (Doctor, Admin, Patient)
const getPatientHistory = async (req, res) => {
    try {
        const { patientId } = req.params;
        const query = { patientId };

        // If user is a doctor, they can only see history with them specifically
        // UNLESS we want doctors to see all history (often they do for clinical context)
        // For now, let's allow Admin to see everything and Doctor to see their own
        if (req.user.role === 'doctor') {
            query.doctorId = req.user.id;
        } else if (req.user.role === 'admin') {
            // Admin sees all history for this patient
        } else if (req.user.role === 'patient') {
            // Patient can only see their own history
            if (req.user.id !== patientId) {
                return res.status(401).json({ message: 'Not authorized to view this history' });
            }
        }

        const history = await require('../models/Appointment').find(query)
            .populate('patientId', 'name email')
            .populate('doctorId', 'name email specialization') // Added doctor info since Admin/Patient sees multiple doctors
            .populate('prescriptions')
            .sort({ date: -1 });

        res.json(history);
    } catch (error) {
        console.error("Error fetching history:", error);
        res.status(500).json({ message: 'Server Error' });
    }
};

module.exports = {
    getDoctors,
    updateDoctorProfile,
    getDoctorProfile,
    getDoctorById,
    getDoctorPatients,
    getPatientHistory
};
